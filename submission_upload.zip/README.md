Alpha Defect Detection - Submission Contents

Files included:
- alpha_defect_detection.ipynb : original notebook
- alpha_defect_detection_executed.ipynb : executed notebook with outputs
- model_lgbm.joblib : trained LightGBM model
- model_threshold.json : chosen probability threshold
- expected_submission.csv : predictions for test.csv (339 rows)

![Overview](images/overview.svg)

How to reproduce:
1. Create and activate the virtualenv (optional):
   python -m venv .venv
   .\.venv\Scripts\activate
2. Install dependencies:
   python -m pip install -r requirements.txt

3. Run notebook in Jupyter or execute via nbconvert.

Notes:
- The notebook enforces Recall=1.0 by selecting a threshold on out-of-fold predictions.
- If precision < 0.9, further tuning (SMOTE, hyperparam search, ensembles) is recommended.
 
License: This repository is provided as-is for submission purposes.
